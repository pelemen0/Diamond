package com.example.trapdiamond;

import java.util.List;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemGroup;
import net.minecraft.tag.BlockTags;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.BuiltinRegistries;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.registry.RegistryKey;
import net.minecraft.util.math.intprovider.ConstantIntProvider;
import net.minecraft.world.Heightmap;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.OreFeatureConfig;
import net.minecraft.world.gen.feature.PlacedFeature;
import net.minecraft.world.gen.placementmodifier.BiomePlacementModifier;
import net.minecraft.world.gen.placementmodifier.CountPlacementModifier;
import net.minecraft.world.gen.placementmodifier.HeightmapPlacementModifier;
import net.minecraft.world.gen.placementmodifier.RandomOffsetPlacementModifier;
import net.minecraft.world.gen.placementmodifier.SquarePlacementModifier;
import net.minecraft.structure.rule.TagMatchRuleTest;

public class TrapDiamondMod implements ModInitializer {
    public static final String MODID = "trapdiamond";

    public static final Block FAKE_DIAMOND_ORE = new FakeDiamondOreBlock(
            FabricBlockSettings.copyOf(Blocks.DIAMOND_ORE).requiresTool());

    @Override
    public void onInitialize() {
        Identifier id = new Identifier(MODID, "fake_diamond_ore");

        Registry.register(Registry.BLOCK, id, FAKE_DIAMOND_ORE);
        Registry.register(Registry.ITEM, id,
                new BlockItem(FAKE_DIAMOND_ORE, new FabricItemSettings().group(ItemGroup.BUILDING_BLOCKS)));

        // Руда заменяет камень, землю/траву и песок (то есть появляется на поверхности)
        List<OreFeatureConfig.Target> targets = List.of(
                OreFeatureConfig.createTarget(new TagMatchRuleTest(BlockTags.BASE_STONE_OVERWORLD), FAKE_DIAMOND_ORE.getDefaultState()),
                OreFeatureConfig.createTarget(new TagMatchRuleTest(BlockTags.DIRT), FAKE_DIAMOND_ORE.getDefaultState()),
                OreFeatureConfig.createTarget(new TagMatchRuleTest(BlockTags.SAND), FAKE_DIAMOND_ORE.getDefaultState()));

        // 3 = размер жилы
        ConfiguredFeature<?, ?> configured = Feature.ORE.configure(new OreFeatureConfig(targets, 3));

        // 25 = сколько жил на чанк (чем больше, тем чаще)
        PlacedFeature placed = configured.withPlacement(
                CountPlacementModifier.of(25),
                SquarePlacementModifier.of(),
                HeightmapPlacementModifier.of(Heightmap.Type.OCEAN_FLOOR_WG),
                RandomOffsetPlacementModifier.vertically(ConstantIntProvider.create(-1)),
                BiomePlacementModifier.of());

        Registry.register(BuiltinRegistries.CONFIGURED_FEATURE, id, configured);
        Registry.register(BuiltinRegistries.PLACED_FEATURE, id, placed);

        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                GenerationStep.Feature.UNDERGROUND_ORES,
                RegistryKey.of(Registry.PLACED_FEATURE_KEY, id));
    }
}
