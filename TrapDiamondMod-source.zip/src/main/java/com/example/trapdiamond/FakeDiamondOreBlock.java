package com.example.trapdiamond;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

public class FakeDiamondOreBlock extends Block {
    // Сила взрыва: у TNT 4.0, у крипера 3.0. Меняй под себя.
    public static final float EXPLOSION_POWER = 2.5f;

    public FakeDiamondOreBlock(Settings settings) {
        super(settings);
    }

    // Вызывается после того, как блок сломан (в любом режиме игры)
    @Override
    public void onBroken(WorldAccess world, BlockPos pos, BlockState state) {
        if (world instanceof World w && !w.isClient) {
            w.createExplosion(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                    EXPLOSION_POWER, Explosion.DestructionType.DESTROY);
        }
        super.onBroken(world, pos, state);
    }
}
